#include <iostream.h>

class samp {
	int i;
public:
	samp(int n) { i = n; }
	int get_i() { return i; }
};

// �����頥� ������ o.i.
int sqr_it(samp o)
{
	return o.get_i() * o.get_i();
}

main()
{
	samp a(10), b(2);

	cout << sqr_it(a) << "\n";
	cout << sqr_it(b) << "\n";

	return 0;
}
