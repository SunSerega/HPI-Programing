#include <iostream.h>
#include <string.h>

class sl_type {
	double balance;
	char name[40];
public:
	sl_type(double b, char *n);
	void show();
};

sl_type::sl_type(double b, char *n)
{
	balance = b;
	strcpy(name, n);
}

void sl_type::show()
{
	cout << "���:" << name;
	cout << ":$" << balance;
	if(balance < 0.0) cout << "***";
	cout << "\n";
}

main()
{
	sl_type	 acc1(100.12, "Johnson");
	sl_type	 acc2(-12.34, "Hedricks");

	acc1.show();
	acc2.show();

	return 0;
}
