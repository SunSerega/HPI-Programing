#include <iostream.h>

main()
{
	cout.setf(ios::uppercase | ios::showbase | ios::hex);

	cout << 88 << '\n';

	cout.unsetf(ios::uppercase);

	cout << 88 << '\n';

	return 0;
}
