#include <iostream.h>
#include <iomanip.h>

main()
{
	cout << hex << 100 << endl;
	cout << oct << 10 << endl;

	cout << setfill('X') << setw(10);
	cout << 100 << " �ਢ�� " << endl;

	return 0;
}
