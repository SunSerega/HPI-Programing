#include <iostream.h>

void swap(int &x, int &y);

main()
{
	int i, j;

	i = 10;
	j = 19;

	cout << "i: " << i << ", ";
	cout << "j: " << j << "\n";

	swap(i, j);

	cout << "��᫥ ����樨: ";
	cout << "i: " << i << ", ";
	cout << "j: " << j << "\n";

	return 0;
}

void swap(int &x, int &y)
{
	int t;

	t = x;
	x = y;
	y = t;
}
