#include <iostream.h>

main()
 {
	int i, j;
	double d;

	i = 10;
	j = 20;
	d = 99.101;

	cout << "��� ��᪮�쪮 �ᥫ: ";
	cout << i << ' ' << j << ' ' << d;

	return 0;
 }
