#include <iostream.h>

ostream &setup  (ostream &stream)
{
	stream.width(10);
	stream.precision(4);
	stream.fill('*');

	return stream;
}

main()
{
	cout << setup << 123.123456;

	return 0;
}
