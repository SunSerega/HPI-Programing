	#include <iostream.h>

	class summation {
		int num;
		long sum; // �㬬� num �ᥫ
	public:
		void set_sum(int n);
		void show_sum() {
			cout << num << " �㬬� ࠢ�� " << sum << "\n";
		}
	};

	void summation::set_sum(int n)
	{
		int i;

		num = n;

		sum = 0;
		for(i=1; i<=n; i++)
			sum += i;
	}

	summation make_sum()
	{
		int i;
		summation temp;

		cout << "������ �᫮: ";

		cin >> i;

		temp.set_sum(i);

		return temp;
	}

	main()
	{
		summation s;

		s = make_sum();

		s.show_sum();

		return 0;
	}
