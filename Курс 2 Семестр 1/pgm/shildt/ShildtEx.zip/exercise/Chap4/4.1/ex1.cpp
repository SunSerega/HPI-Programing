	#include <iostream.h>

	class letters {
		char ch;
	public:
		letters(char c) { ch = c; }
		char get_ch() { return ch; }
	};

	main()
	{
		letters ob[10] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j' };

		int i;

		for(i=0; i<10; i++)
			cout << ob[ i ].get_ch() << ' ';

		cout << "\n";

		return 0;
	}
