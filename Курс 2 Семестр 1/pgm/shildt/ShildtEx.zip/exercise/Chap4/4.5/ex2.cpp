	#include <iostream.h>

	main()
	{
		double *p;

		p = new double(-123.0987);

		cout << *p << '\n';

		return 0;
	}
