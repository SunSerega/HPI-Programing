	// �ᯮ�짮����� 㪠��⥫� this
	#include <iostream.h>

	class myclass {
		int a, b;
	public:
		myclass(int n, int m) { this->a = n; this->b = m; }
		int add() { return this->a + this->b; }
		void show();
	};

	void myclass::show()
	{
		int t;
	
		t = this->add(); // �맮� �㭪樨-童��
		cout << t <<"\n";
	}

	main()
	{
		myclass ob(10, 14);

		ob.show();

		return 0;
	}
