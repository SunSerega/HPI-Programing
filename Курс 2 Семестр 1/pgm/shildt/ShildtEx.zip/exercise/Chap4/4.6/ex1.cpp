	#include <iostream.h>

	void rneg(int &i);
	void pneg(int *i);

	main()
	{
		int i = 10;
		int j = 20;

		rneg(i);
		pneg(&j);

		cout << i << ' ' << j << '\n';

		return 0;
	}

	void rneg(int &i)
	{
		i = - i;
	}

	void pneg(int *i)
	{
		*i = -*i;
	}
