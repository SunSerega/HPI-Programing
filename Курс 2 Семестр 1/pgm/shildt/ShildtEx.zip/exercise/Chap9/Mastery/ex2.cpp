	#include <iostream.h>
	#include <ctype.h>

	istream &findalpha(istream &stream)
	{
		char ch;

		do {
			stream.get(ch);
		} while(!isalpha(ch));
		return stream;
	}

	main()
	{
		char str[80];

		cin >> findalpha >> str;
		cout << str << "\n";

		return 0;
	}
