	#include <iostream.h>

	ostream &tabs(ostream &stream)
	{
		stream << '\t' << '\t' << '\t';
		stream.width(20);

		return stream;
	}

	main()
	{
		cout << tabs << "�஢�ઠ\n";

		return 0;
	}
