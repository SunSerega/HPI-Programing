	// �뢮� ᮤ�ন���� ����� account � 䠩� � �ᯮ�짮������ ᮡ�⢥����
	// �㭪樨 �뢮��.
	#include <iostream.h>
	#include <fstream.h>
	#include <string.h>

	class account {
		int custnum;
		char name[80];
		double balance;
	public:
		account(int c, char *n, double b)
		{
			custnum = c;
			strcpy(name, n);
			balance = b;
		}
		friend ostream &operator<<(ostream &stream, account ob);
	};

	ostream &operator<<(ostream &stream, account ob)
	{
		stream << ob.custnum << ' ';
		stream << ob.name << ' ' << ob.balance;
		stream << '\n';

		return stream;
	}

	main()
	{
		account Rex(1011, "Ralph Rex", 12323.34);
		ofstream out("accounts");

		out << Rex;

		out.close();

		return 0;
	}
