	#include <iostream.h>

	main()
	{
		cout.precision(4);
		cout << 10.0/3.0 << '\n';

		return 0;
	}

