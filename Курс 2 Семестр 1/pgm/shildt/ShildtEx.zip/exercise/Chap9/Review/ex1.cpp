	#include <iostream.h>

	main()
	{
		cout.width(40);
		cout.fill(':');

		cout << "C++ �४�ᥭ" << '\n';

		return 0;
	}
