	#include <iostream.h>
	#include <iomanip.h>

	main()
	{
		cout << setprecision(4) << 10.0/3.0 << '\n';

		return 0;
	}
