	#include <iostream.h>

	class date {
		char d[9]; // ��� �࠭���� � ���� ��ப�: mm/dd/yy
	public:
		friend ostream &operator<<(ostream &stream, date ob);
		friend istream &operator>>(istream &stream, date &ob);
	};

	ostream &operator<<(ostream &stream, date ob)
	{
		stream << ob.d << '\n';

		return stream;
	}

	istream &operator>>(istream &stream, date &ob)
	{
		cout << "������ ���� (mm/dd/yy): ";
		stream >> ob.d;

		return stream;
	}

	main()
	{
		date ob;

		cin >> ob;
		cout << ob;

		return 0;
	}
