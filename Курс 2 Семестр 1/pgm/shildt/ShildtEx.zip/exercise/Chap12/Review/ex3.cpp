	#include <iostream.h>

// �����頥� a � �⥯��� b
template <class X> X gexp(X a, X b)
{
		X i, result=1;

	for(i=0; i<b; i++) result *= a;

		return result;
}

main()
{
	cout << gexp(2, 3) << endl;
	cout << gexp(10.0, 2.0);

	return 0;
}
