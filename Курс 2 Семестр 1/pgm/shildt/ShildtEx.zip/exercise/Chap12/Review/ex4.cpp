	#include <iostream.h>
#include <fstream.h>

template <class CoordType> class coord {
		CoordType x, y; 
public:
		coord(CoordType i, CoordType j) { x = i; y = j; }
		void show() {cout << x << ", " << y << endl;}
};

main()
{
		coord<int> o1(1, 2), o2(3, 4);

		o1.show();
		o2.show();

		coord<double> o3(0.0, 0.23), o4(10.19, 3.098);

		o3.show();
		o4.show();

	return 0;
}
