	#include <iostream.h>

	ostream &setsci(ostream &stream)
	{
		stream.setf(ios::scientific | ios::uppercase);

		return stream;
	}

	main()
	{
		double f = 123.23;

		cout << setsci << f;
		cout << '\n';

		return 0;
	}
