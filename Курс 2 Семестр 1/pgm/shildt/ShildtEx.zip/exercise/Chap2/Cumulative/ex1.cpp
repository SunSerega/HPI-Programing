	#include <iostream.h>

	class prompt {
		int count;
	public:
		prompt(char *s) { cout << s; cin >> count; }
		~prompt();
	};

	prompt::~prompt() {
		int i, j;
		for(i=0; i<count; i++) {
			cout << '\a';
			for(j=0; j<32000; j++); // ��㧠
		}
	}

	main()
	{
		prompt ob("������ �᫮: ");

		return 0;
	}
