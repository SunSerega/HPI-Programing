	#include <iostream.h>
 	#include <stdlib.h>

	class dice {
		int val;
	public:
		void roll();
	};

	void dice::roll()
	{
		val = (rand() % 6) +1; // ������� �ᥫ �� 1 �� 6
		cout << val << "\n";
	}

	main()	
	{
		dice one, two;

		one.roll();
		two.roll();
		one.roll();
		two.roll();
		one.roll();
		two.roll();

		return 0;
	}
