	#include <iostream.h>

	class ftoi {
		double feet;
		double inches;
	public:
		ftoi(double f);
	};

	ftoi::ftoi(double f)
	{
		feet = f;
		inches = feet * 12;
		cout << feet << "��⮢ ࠢ�� " << inches << "���.\n";
	}

	main()	
	{
		ftoi a(12.0), b(99.0);

		return 0;
	}
