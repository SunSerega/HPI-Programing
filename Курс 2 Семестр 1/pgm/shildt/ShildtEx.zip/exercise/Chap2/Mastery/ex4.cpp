	#include <iostream.h>

	class area_cl {
	public:
		double height;
		double width;
	};

	class box : public area_cl {
	public:
		box(double h, double w) { height = h; width = w; }
		double area() { return height * width; }
	};

	class isosceles : public area_cl {
	public:
		isosceles(double h, double w) { height = h; width = w; }
		double area() { return 0.5 * height * width; }
	};

	class cylinder : public area_cl {
	public:
		cylinder(double h, double w) { height = h; width = w; }
		double area() 
		{
			return (2 * 3.1416 * (width/2) * (width/2)) + (3.1416 * height * width);
		}
	};

	main()
	{
		box b(10.0, 5.0);
		isosceles i(4.0, 6.0);
		cylinder c(3.0, 4.0);

		cout << "��אַ㣮�쭨�: " << b.area() << "\n";
		cout << "��㣮�쭨�: " << i.area() << "\n";
		cout << "�������: " << c.area() << "\n";

		return 0;
	}
