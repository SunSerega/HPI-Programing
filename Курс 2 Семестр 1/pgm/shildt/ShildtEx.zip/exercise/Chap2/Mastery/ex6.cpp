	#include <iostream.h>

	class myclass {
		int i, j;
	public:
		myclass(int x, int y) { i = x; j = y; }
		void show() { cout << i << " " << j ; }
	};

	main()
	{
		myclass count(2, 3);

		count.show();

		return 0;
	}
