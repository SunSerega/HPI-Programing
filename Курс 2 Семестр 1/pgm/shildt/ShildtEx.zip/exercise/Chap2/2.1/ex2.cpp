	// ������ ᥪ㭤����
	#include <iostream.h>
	#include <time.h>

	class stopwatch {
		double begin, end;
	public:
		stopwatch(); 
		~stopwatch(); 
		void start();
		void stop();
		void show();
	};

	stopwatch::stopwatch()
	{
		begin = end = 0.0;
	}

	stopwatch::~stopwatch()
	{
		cout << "�������� ��ꥪ� stopwatch ...";
		show();
	}

	void stopwatch::start()
	{
		begin = (double) clock() / CLK_TCK;
	}

	void stopwatch::stop()
	{
		end = (double) clock() / CLK_TCK;
	}

	void stopwatch::show()
	{
		cout << "��襤襥 �६�: " << end - begin;
		cout << "\n";
	}

	main()
	{
		stopwatch watch; 
		long i;

		watch.start();
		for(i=0; i<320000; i++); // 横� ����প�
		watch.stop();

		watch.show();

		return 0;
	}
