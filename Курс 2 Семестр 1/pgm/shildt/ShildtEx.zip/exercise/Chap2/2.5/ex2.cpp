	#include <iostream.h>

	union swap {
		unsigned char c[2];
		unsigned i;
		swap(unsigned x);
		void swp();
	};

	swap::swap(unsigned x)
	{
		i = x;
	}

	void swap::swp()
	{
		unsigned char temp;

		temp = c[0];
		c[0] = c[1];
		c[1] = temp;
	}

	main()
	{
		swap ob(1); 

		ob.swp();
		cout << ob.i;

		return 0;
	}
