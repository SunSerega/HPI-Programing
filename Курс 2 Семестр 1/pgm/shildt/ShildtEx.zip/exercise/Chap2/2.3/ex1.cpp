	#include <iostream.h>

	class area_cl {
	public:
		double height;
		double width;
	};

	class box : public area_cl {
	public:
		box(double h, double w);
		double area();
	};

	class isosceles : public area_cl {
	public:
		isosceles(double h, double w);
		double area();
	};

	box::box(double h,double w)
	{
		height = h;	
		width = w;	
	}

	isosceles::isosceles(double h,double w)
	{
		height = h;	
		width = w;	
	}

	double box::area()
	{
		return width * height;
	}

	double isosceles::area()
	{
		return 0.5 * width * height;
	}

	main()
	{
		box b(10.0, 5.0);
		isosceles i(4.0, 6.0);

		cout << "��אַ㣮�쭨�: " << b.area() << "\n";
		cout << "��㣮�쭨�: " << i.area() << "\n";

		return 0;
	}
