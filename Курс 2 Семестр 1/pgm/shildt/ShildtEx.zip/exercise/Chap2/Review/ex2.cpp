	#include <iostream.h>
	#include <string.h>

	class addr {
		char name[40]; 
		char street[40]; 
		char city[30]; 
		char state[3]; 
		char zip[10]; 
	public:
		void store(char *n, char *s, char *c, char *t, char *z);
		void display();
	};

	void addr::store(char *n, char *s, char *c, char *t, char *z)
	{
		strcpy(name, n);
		strcpy(street, s);
		strcpy(city, c);
		strcpy(state, t);
		strcpy(zip, z);
	}

	void addr::display()
	{
		cout << name << "\n";
		cout << street << "\n";
		cout << city << "\n";
		cout << state << "\n";
		cout << zip << "\n\n";
	}

	main()
	{
		addr a;

		a.store("�. �. ������", "���᪨� ��ᯥ��", "�-������", "���","46576");

		a.display();

		return 0;
	}
