	#include <iostream.h>

	main()
	{
		float *f;
		int *i;

		f = new float;
		i = new int;

		if(!f || !i) {
			cout << "�訡�� �뤥����� �����\n";
			return 1;
		}

		*f = 10.101;
		*i = 100;

		cout << *f << ' ' << *i << '\n';

		delete f;
		delete i;

		return 0;
	}
