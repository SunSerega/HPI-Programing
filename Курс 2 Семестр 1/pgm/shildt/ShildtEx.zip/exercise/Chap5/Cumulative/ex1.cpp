	#include <iostream.h>

	void order(int &a, int &b)
	{
		int t;

		if(a<b) return;
		else { // a � b �������� ���⠬�
			t = a;
			a = b;
			b = t;
		}
	}

	main()
	{
		int x = 10, y = 5;

		cout << "x: " << x << ", y: " << y << '\n';

		order(x, y);
		cout << "x: " << x << ", y: " << y << '\n';

		return 0;
	}
