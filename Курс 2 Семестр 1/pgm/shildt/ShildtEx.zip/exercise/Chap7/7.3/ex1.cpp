	#include <iostream.h>
	#include <string.h>

	class mybase {
		char str[80];
	public:
		mybase(char *s) { strcpy(str, s); }
		char *get() { return str; }
	};

	class myderived : public mybase {
		int len;
	public:
		myderived(char *s) : mybase(s) {
			len = strlen(s);
		} 
		int getlen() { return len; }
		void show() { cout << get() << '\n'; }
	};

	main()
	{
		myderived ob("�ਢ��");

		ob.show();
		cout << ob.getlen() << '\n';

		return 0;
	}
