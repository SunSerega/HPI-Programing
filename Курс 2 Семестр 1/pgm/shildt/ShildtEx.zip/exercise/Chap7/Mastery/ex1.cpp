	#include <iostream.h>

	class building {
	protected:
		int floors;
		int rooms;
		double footage;
	};

	class house : public building {
		int bedrooms;
		int bathrooms;
	public:
		house(int f, int r, double ft, int br, int bth) {
			floors = f; rooms = r; footage = ft; bedrooms = br; bathrooms = bth;
		}
		void show() {
			cout << "�⠦��: " << floors << '\n';
			cout << "������: " << rooms << '\n';
			cout << "���ࠦ: " << footage << '\n';
			cout << "ᯠ���: " << bedrooms << '\n';
			cout << "������: " << bathrooms << '\n';
		}
	};

	class office : public building {
		int phones;
		int extinguishers;
	public:
		office(int f, int r, double ft, int p, int ext) {
			floors = f; rooms = r; footage = ft; phones = p; extinguishers = ext;
		}
		void show() {
			cout << "�⠦��: " << floors << '\n';
			cout << "������: " << rooms << '\n';
			cout << "���ࠦ: " << footage << '\n';
			cout << "⥫�䮭��: " << phones << '\n';
			cout << "�������⥫��: " << extinguishers << '\n';
		}
	};

	main()
	{
		house h_ob(2, 12, 5000, 6, 4);
		office o_ob(4, 25, 12000, 30, 8);

		cout << "����� ���: \n";
		h_ob.show();

		cout << "\n���: \n";
		o_ob.show();

		return 0;
	}
