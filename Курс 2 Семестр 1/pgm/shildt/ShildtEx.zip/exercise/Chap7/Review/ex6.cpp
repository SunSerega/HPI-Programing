	#include <iostream.h>

	class array {
		int nums[10];
	public:
		array();
		void set(int n[10]);
		void show();
		array operator++();
		friend array operator--(array &ob);
	};

	array::array()
	{
		int i;

		for(i = 0; i < 10; i++) nums[ i ] = 0;
	}

	void array::set(int *n)
	{
		int i;

		for(i = 0; i < 10; i++) nums[ i ] = n[ i ];
	}

	void array::show()
	{
		int i;

		for(i = 0; i < 10; i++) 
			cout << nums[ i ] << ' ';

		cout << "\n";
	}

	// ��ॣ�㧪� 㭠୮� ����樨 � �ᯮ�짮������ �㭪樨-童��
	array array::operator++()
	{
		int i;

		for(i=0; i<10; i++) nums[ i ]++;

		return *this;
	}

	// ��ॣ�㧪� 㭠୮� ����樨 � �ᯮ�짮������ ��㦥�⢥���� �㭪樨
	array operator--(array &ob)
	{
		int i;

		for(i=0; i<10; i++) ob.nums[ i ]--;

		return ob;
	}

	main()
	{
		array o1, o2, o3;

		int i[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		o1.set(i);
		o2.set(i);

		o3 = ++o1;
		o3.show();

		o3 = --o1;
		o3.show();

		return 0;
	}
