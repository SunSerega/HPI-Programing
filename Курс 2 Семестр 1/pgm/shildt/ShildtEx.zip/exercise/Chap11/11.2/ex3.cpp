	#include <iostream.h>

template <class X> class input {
X data;
public:
	input(char *s, X min, X max);
	// ...
};

template <class X>
input<X>::input(char *s, X min, X max)
{
		do {
			cout << s << ": ";
			cin >> data;
	} while(data<min || data>max);
}

main()
{
	input<int> i("���� 楫��", 0, 10);
	input<char> c("���� ᨬ�����", 'A', 'Z');

	return 0;
}
