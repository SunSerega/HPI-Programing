	#include <iostream.h>
	#include <string.h>

template <class X> int find(X object, X *list, int size)
{
		int i;

		for(i=0; i<size; i++)
		if(object == list[i]) return i;
		return -1;
}

main()
{
		int a[]={1, 2, 3, 4};
		char *c="�� �஢�ઠ";
		double d[]={1.1, 2.2, 3.3};

		cout << find(3, a, 4);
	cout << endl;
		cout << find('a', c, (int) strlen(c));
	cout << endl;
		cout << find(0.0, d, 3);

	return 0;
}
