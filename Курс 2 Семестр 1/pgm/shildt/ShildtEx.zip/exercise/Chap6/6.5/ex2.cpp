	// ��ॣ�㧪� * ��� ob*int � int*ob.
	#include <iostream.h>

	class coord {
		int x, y; // ���祭�� ���न���
	public:
		coord() { x = 0; y= 0; }
		coord(int i, int j) { x = i; y = j; }
		void get_xy(int &i, int &j) { i = x; j = y; }
		friend coord operator*(coord ob1, int i);
		friend coord operator*(int i, coord ob2);
	};

	// ��ॣ�㧪� * ���� ᯮᮡ��.
	coord operator*(coord ob1, int i)
	{
		coord temp;

		temp.x = ob1.x * i;
		temp.y = ob1.y * i;

		return temp;
	}

	// ��ॣ�㧪� * ���� ᯮᮡ��.
	coord operator*(int i, coord ob2)
	{
		coord temp;

		temp.x = ob2.x * i;
		temp.y = ob2.y * i;

		return temp;
	}

	main()
	{
		coord o1(10, 10), o2;
		int x, y;

		o2 = o1 * 2; // ob * int
		o2.get_xy(x, y);
		cout << "(o1 * 2) X: " << x << ", Y: " << y << "\n";

		o2 = 3 * o1; // int * ob
		o2.get_xy(x, y);
		cout << "(3 * o1) X: " << x << ", Y: " << y << "\n";

		return 0;
	}
