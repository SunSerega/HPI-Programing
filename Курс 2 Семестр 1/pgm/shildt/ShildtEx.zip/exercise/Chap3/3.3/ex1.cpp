	#include <iostream.h>

	class who {
		char name;
	public:
		who(char c) {
			name = c;
			cout << "�������� who #";
			cout << name << "\n";
		}
		~who() { cout << "�������� who #" << name << "\n"; }
	};

	who make_who()
	{
		who temp('B');
		return temp;
	}

	main()
	{
		who ob('A');

		make_who();

		return 0;
	}
