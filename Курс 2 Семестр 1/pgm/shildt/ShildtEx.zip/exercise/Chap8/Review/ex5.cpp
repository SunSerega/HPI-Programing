	#include <iostream.h>

	class base {
		int i, j;
	public:
		base(int x, int y) {i = x; j = y; }
		void showij() { cout << i << ' ' << j << '\n'; }
	};

	class derived : public base {
		int k;
	public:
		derived(int a, int b, int c) : base(b, c) {
			k = a;
		}
		void show() { cout << k << ' '; showij(); }
	};

	main()
	{
		derived ob(1, 2, 3);

		ob.show();

		return 0;
	}
