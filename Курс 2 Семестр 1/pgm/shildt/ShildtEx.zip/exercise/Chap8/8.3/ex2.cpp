	#include <iostream.h>
	#include <string.h>

	void center(char *s);

	main()
	{
		center("�� �����!");
		center("� �� �++.");

		return 0;
	}

	void center(char *s)
	{
		int len;

		len = 40 + (strlen(s)/2);

		cout.width(len); 
		cout << s << "\n"; 
	}
