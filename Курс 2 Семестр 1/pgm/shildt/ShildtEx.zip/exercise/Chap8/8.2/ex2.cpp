	#include <iostream.h>

	main()
	{

		cout.setf(ios::showpoint | ios::uppercase | ios::scientific);

		cout << 100.0;

		return 0;
	}
