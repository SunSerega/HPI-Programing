	#include <iostream.h>

	main()
	{

		cout.setf(ios::showpos);

		cout << -10 << ' ' << 10 << '\n';

		return 0;
	}
