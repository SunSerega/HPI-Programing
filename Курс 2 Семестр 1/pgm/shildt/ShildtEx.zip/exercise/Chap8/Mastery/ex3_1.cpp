	#include <iostream.h>

	main()
	{
		cout << 100 << ' ';

		cout << hex << 100 << ' ';

		cout << oct << 100 << '\n';

		return 0;
	}
