	#include <iostream.h>
	#include <iomanip.h>

	main()
	{
		cout << setiosflags(ios::left);
		cout << setprecision(2);
		cout << setfill('*');
		cout << setw(20);

		cout << 1000.5354 << '\n';

		return 0;
	}
