	#include <iostream.h>

	main()
	{
		cout.setf(ios::left);
		cout.precision(2);
		cout.fill('*');
		cout.width(20);

		cout << 1000.5354 << '\n';

		return 0;
	}
