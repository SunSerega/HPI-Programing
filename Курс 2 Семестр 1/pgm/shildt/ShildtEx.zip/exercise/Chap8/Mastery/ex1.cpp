	#include <iostream.h>

	main()
	{
		cout << 100 << ' ';

		cout.setf(ios::hex);
		cout << 100 << ' ';

		cout.unsetf(ios::hex); // ��� 䫠�� hex
		cout.setf(ios::oct);
		cout << 100 << '\n';

		return 0;
	}
