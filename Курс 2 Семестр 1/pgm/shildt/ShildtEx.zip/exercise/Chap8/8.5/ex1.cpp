	#include <iostream.h>
	#include <string.h>
	#include <stdlib.h>

	class strtype {
		char *p;
		int len;
	public:
		strtype(char *ptr);
		~strtype(); 
		friend ostream &operator<<(ostream &stream, strtype &ob);
	};

	strtype::strtype(char *ptr)
	{
		len = strlen(ptr);
		p = new char [len +1];
		if(!p) {
			cout << "�訡�� �뤥����� �����\n";
			exit(1);
		}
		strcpy(p, ptr);	
	}

	strtype::~strtype()
	{
		delete p;
	}

	ostream &operator<<(ostream &stream, strtype &ob)
	{
		stream << ob.p;

		return stream;
	}

	main()
	{
		strtype s1("�� �஢�ઠ"), s2("� �� �++");

		cout << s1;
		cout << endl << s2 << endl;

		return 0;
	}
