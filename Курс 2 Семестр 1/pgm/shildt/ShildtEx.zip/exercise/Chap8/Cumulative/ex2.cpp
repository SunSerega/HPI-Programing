	#include <iostream.h>
	#include <time.h>

	class watch {
		time_t t;
	public:
		watch() { t = time(NULL); }
		friend ostream &operator<<(ostream &stream, watch ob);
	};

	ostream &operator<<(ostream &stream, watch ob)
	{
		struct tm *localt;

		localt = localtime(&ob.t);
		stream << asctime(localt) << endl;

		return stream;
	}

	main()
	{
		watch w;

		cout << w;

		return 0;
	}
