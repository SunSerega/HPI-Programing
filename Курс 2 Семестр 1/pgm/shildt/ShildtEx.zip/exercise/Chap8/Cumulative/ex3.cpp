	#include <iostream.h>

	class ft_to_inches {
		double feet;
		double inches;
	public:
		void set(double f) {
			feet = f;
			inches = f * 12;
		}
		friend ostream &operator<<(ostream &stream, ft_to_inches ob);
		friend istream &operator>>(istream &stream, ft_to_inches &ob);
	};

	istream &operator>>(istream &stream, ft_to_inches &ob)
	{
		double f;

		cout << "������ �᫮ ��⮢: ";
		stream >> f;
		ob.set(f);

		return stream;
	}

	ostream &operator<<(ostream &stream, ft_to_inches ob)
	{
		stream << ob.feet << " ��⮢ ࠢ�� " << ob.inches;
		stream  << " ���\n";

		return stream;
	}

	main()
	{
		ft_to_inches x;

		cin >> x;
		cout << x;

		return 0;
	}
