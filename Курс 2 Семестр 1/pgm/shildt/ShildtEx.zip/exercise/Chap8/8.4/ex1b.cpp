	#include <iostream.h>
	#include <string.h>
	#include <iomanip.h>

	void center(char *s);

	main()
	{
		center("�� �����!");
		center("� �� �++.");

		return 0;
	}

	void center(char *s)
	{
		int len;

		len = 40 + (strlen(s)/2);

		cout << setw(len) << s << "\n"; 
	}
