	#include <iostream.h>
	#include <string.h>
	#include <stdlib.h>

	class strtype {
		char *p;
		int len;
	public:
		strtype(char *ptr);
		~strtype(); 
		friend ostream &operator<<(ostream &stream, strtype &ob);
		friend istream &operator>>(istream &stream, strtype &ob);
	};

	strtype::strtype(char *ptr)
	{
		len = strlen(ptr);
		p = new char [len +1];
		if(!p) {
			cout << "�訡�� �뤥����� �����\n";
			exit(1);
		}
		strcpy(p, ptr);	
	}

	strtype::~strtype()
	{
		delete p;
	}

	ostream &operator<<(ostream &stream, strtype &ob)
	{
		stream << ob.p;

		return stream;
	}

	istream &operator>>(istream &stream, strtype &ob)
	{
		char temp[255];

		stream >> temp;

		if(strlen(temp) >= ob.len) {
			delete ob.p;
			ob.p = new char[strlen(temp) + 1];
			if(!ob.p) {
				cout << "�訡�� �뤥����� �����\n";
				exit(1);
			}
		}
		strcpy(ob.p, temp);

		return stream;
	}

	main()
	{
		strtype s1("�� �஢�ઠ"), s2("� �� �++");

		cout << s1;
		cout << '\n' << s2;

		cout << "\n������ ��ப�: ";
		cin >> s1;
		cout << s1;

		return 0;
	}
